/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.util.Date;

/**
 *
 * @author DeAsis
 */
public class ViewModelCompras {
    private int ID_Compra;
    private Date fechaCompra;
    private double montoCompra;
    private int ID_Cliente;

    /**
     * @return the ID_Compra
     */
    public int getID_Compra() {
        return ID_Compra;
    }

    /**
     * @param ID_Compra the ID_Compra to set
     */
    public void setID_Compra(int ID_Compra) {
        this.ID_Compra = ID_Compra;
    }

    /**
     * @return the fechaCompra
     */
    public Date getFechaCompra() {
        return fechaCompra;
    }

    /**
     * @param fechaCompra the fechaCompra to set
     */
    public void setFechaCompra(Date fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public double getMontoCompra() {
        return montoCompra;
    }


    public void setMontoCompra(double montoCompra) {
        this.montoCompra = montoCompra;
    }

    /**
     * @return the ID_Cliente
     */
    public int getID_Cliente() {
        return ID_Cliente;
    }

    /**
     * @param ID_Cliente the ID_Cliente to set
     */
    public void setID_Cliente(int ID_Cliente) {
        this.ID_Cliente = ID_Cliente;
    }

    
}
