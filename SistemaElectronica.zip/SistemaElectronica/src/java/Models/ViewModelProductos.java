
package Models;

/**
 *
 * @author DeAsis
 */
public class ViewModelProductos {
   
    private int ID_Producto;
    private String descripcion;
    private double precio;
    private int existencia;
   
   /** 
    public ViewModelProductos(int idproducto,String nombreProducto, double precio, int existencia){
        this.ID_Producto= idproducto;
        this.descripcion= nombreProducto;
        this.precio = precio;
        this.existencia = existencia;
    }
     */
    public int getID_Producto() {
        return ID_Producto;
    }

    /**
     * @param ID_Producto the ID_Producto to set
     */
    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * @return the existencia
     */
    public int getExistencia() {
        return existencia;
    }

    /**
     * @param existencia the existencia to set
     */
    public void setExistencia(int existencia) {
        this.existencia = existencia;
    }

    
    
    
}
