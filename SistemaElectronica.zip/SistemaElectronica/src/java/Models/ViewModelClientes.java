
package Models;

/**
 *
 * @author DeAsis
 */
public class ViewModelClientes {

    private int ID_Cliente;
    private String nombresCliente;
    private String apellidosCliente;
    private String telefonoCliente;
    private String emailCliente;
    private int ID_Direccion; 

    
    /**
     * @return the ID_Cliente
     */
    public int getID_Cliente() {
        return ID_Cliente;
    }

    /**
     * @param ID_Cliente the ID_Cliente to set
     */
    public void setID_Cliente(int ID_Cliente) {
        this.ID_Cliente = ID_Cliente;
    }

    /**
     * @return the NombresCliente
     */
    public String getNombresCliente() {
        return nombresCliente;
    }

    /**
     * @param NombresCliente the NombresCliente to set
     */
    public void setNombresCliente(String NombresCliente) {
        this.nombresCliente = NombresCliente;
    }

    /**
     * @return the ApellidosCliente
     */
    public String getApellidosCliente() {
        return apellidosCliente;
    }

    /**
     * @param ApellidosCliente the ApellidosCliente to set
     */
    public void setApellidosCliente(String apellidosCliente) {
        this.apellidosCliente = apellidosCliente;
    }

    /**
     * @return the TelefonoCliente
     */
    public String getTelefonoCliente() {
        return telefonoCliente;
    }

    /**
     * @param TelefonoCliente the TelefonoCliente to set
     */
    public void setTelefonoCliente(String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }

    /**
     * @return the EmailCliente
     */
    public String getEmailCliente() {
        return emailCliente;
    }

    /**
     * @param EmailCliente the EmailCliente to set
     */
    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }

    /**
     * @return the ID_Direccion
     */
    public int getID_Direccion() {
        return ID_Direccion;
    }

    /**
     * @param ID_Direccion the ID_Direccion to set
     */
    public void setID_Direccion(int ID_Direccion) {
        this.ID_Direccion = ID_Direccion;
    }


}
